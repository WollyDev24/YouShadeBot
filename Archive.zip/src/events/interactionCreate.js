import { MessageFlags } from "discord.js";

function friendlyError(err) {
  if (err.code === 10062) return "This command timed out — try again.";
  if (err.code === 50013) return "I'm missing permissions to do that.";
  if (err.code === 50035 || err.rawError?.message?.includes("Invalid Form Body"))
    return "Invalid input — check the arguments.";
  if (err.message?.includes("Missing Permission"))
    return "I'm missing permissions to do that.";
  return "Something went wrong while running that command.";
}

export default {
  name: "interactionCreate",
  async execute(client, interaction) {
    if (!interaction.isChatInputCommand()) return;

    const cmd = client.commands.get(interaction.commandName);
    if (!cmd) return;

    try {
      await cmd.execute(client, interaction);
    } catch (err) {
      console.error(`[error] /${interaction.commandName}:`, err);
      const msg = friendlyError(err);
      const safe = { content: msg, flags: MessageFlags.Ephemeral };
      try {
        if (interaction.deferred) {
          await interaction.editReply(safe);
        } else if (interaction.replied) {
          await interaction.followUp(safe);
        } else {
          await interaction.reply(safe);
        }
      } catch (e2) {
        console.error("[error] failed to send error reply:", e2.message);
      }
    }
  }
};
