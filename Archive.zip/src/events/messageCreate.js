import { getGuildCounting, incrementCount, resetCount } from "../utils/counting.js";

const FAILS = [
  "{user} broke the count!",
  "Oof. {user} just reset the count.",
  "Nice try, {user}. The count starts over.",
  "{user} ruined it. Back to zero.",
  "That's not how counting works, {user}.",
  "{user} dropped the ball. Count resets!"
];

const MILESTONES = new Set([69, 100, 200, 300, 400, 500, 1000, 1500, 2000]);

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function extractNumber(content) {
  const m = content.trim().match(/^(\d{1,9})/);
  return m ? parseInt(m[1], 10) : null;
}

function fail(guild, message, extra) {
  const c = getGuildCounting(guild.id);
  const hadRun = c.current > 0;
  if (hadRun) resetCount(guild.id);

  message.react("\u{1F534}").catch(() => {});

  const line = pick(FAILS).replace("{user}", `<@${message.author.id}>`);
  const note = extra ? ` ${extra}` : "";
  const tail = hadRun ? ` The previous run hit **${c.best}**.` : "";
  message.channel
    .send(`${line}${note}${tail}`)
    .then((m) => setTimeout(() => m.delete().catch(() => {}), 8000))
    .catch(() => {});
}

export default {
  name: "messageCreate",
  async execute(client, message) {
    if (message.author.bot) return;
    const guild = message.guild;
    if (!guild) return;

    const cfg = getGuildCounting(guild.id);
    if (!cfg.channelId || message.channel.id !== cfg.channelId) return;

    const num = extractNumber(message.content);
    const expected = cfg.current + 1;

    if (num !== null && num === expected && message.author.id !== cfg.lastUserId) {
      incrementCount(guild.id, message.author.id);
      const c = getGuildCounting(guild.id);
      if (MILESTONES.has(c.current)) {
        message.react(c.current === 69 ? "\u{1F525}" : "\u{1F389}").catch(() => {});
      }
      return;
    }

    if (cfg.chill) {
      message.react("\u{1F534}").catch(() => {});
      return; // chill mode: flag it but never reset the count
    }

    if (num === null) {
      if (cfg.strict) return fail(guild, message, "(counting is strict here — numbers only!)");
      return; // lenient: ignore non-number chatter
    }

    if (message.author.id === cfg.lastUserId) {
      return fail(guild, message, "(you can't count twice in a row!)");
    }

    return fail(guild, message);
  }
};