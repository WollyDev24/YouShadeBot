import express from "express";
import cookieParser from "cookie-parser";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { getData, save } from "../utils/db.js";
import { getGuildTemp } from "../utils/temp.js";
import { setupStats, disableStats, refreshStats, statsConfig } from "../utils/stats.js";
import { registerCommands } from "../utils/register.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(__dirname, "public");

function authPassword() {
  const pw = process.env.PANEL_PASSWORD || "admin";
  return crypto.createHash("sha256").update(pw).digest("hex");
}

async function guildPayload(client, guild) {
  const temp = getGuildTemp(guild.id).trigger ?? null;
  const stats = statsConfig(guild.id);

  let triggerName = null;
  if (temp) triggerName = guild.channels.cache.get(temp)?.name ?? null;

  const channels = guild.channels.cache
    .filter((c) => c.type === 0 || c.type === 2)
    .map((c) => ({
      id: c.id,
      name: c.name,
      type: c.type,
      parent: c.parentId
    }))
    .sort((a, b) => a.name.localeCompare(b.name));

  return {
    id: guild.id,
    name: guild.name,
    icon: guild.iconURL({ size: 128 }),
    memberCount: guild.memberCount,
    temp: {
      enabled: Boolean(temp),
      triggerId: temp,
      triggerName
    },
    stats: {
      enabled: stats.enabled,
      channels: stats.channels,
      categoryId: stats.categoryId
    },
    channels
  };
}

export function startPanel(client) {
  const app = express();
  app.use(express.json());
  app.use(cookieParser());

  const AUTH_COOKIE = "ys_panel";

  const requireAuth = (req, res, next) => {
    if (req.cookies?.[AUTH_COOKIE] === authPassword()) return next();
    return res.status(401).json({ error: "unauthorized" });
  };

  app.post("/api/login", (req, res) => {
    const { password } = req.body ?? {};
    if (crypto.createHash("sha256").update(String(password)).digest("hex") !== authPassword()) {
      return res.status(401).json({ error: "wrong password" });
    }
    res.cookie(AUTH_COOKIE, authPassword(), {
      httpOnly: true,
      sameSite: "strict",
      maxAge: 7 * 24 * 60 * 60 * 1000
    });
    return res.json({ ok: true });
  });

  app.post("/api/logout", (req, res) => {
    res.clearCookie(AUTH_COOKIE);
    return res.json({ ok: true });
  });

  app.get("/api/status", requireAuth, async (req, res) => {
    if (!client.user) return res.json({ online: false });
    const guilds = client.guilds.cache;
    return res.json({
      online: true,
      tag: client.user.tag,
      id: client.user.id,
      ping: Math.round(client.ws.ping),
      uptime: Math.floor(process.uptime()),
      guildCount: guilds.size,
      totalMembers: guilds.reduce((n, g) => n + g.memberCount, 0)
    });
  });

  app.get("/api/guilds", requireAuth, async (req, res) => {
    const guilds = client.guilds.cache;
    if (!guilds.size) return res.json([]);
    const out = [];
    for (const guild of guilds.values()) {
      out.push(await guildPayload(client, guild));
    }
    return res.json(out.sort((a, b) => a.name.localeCompare(b.name)));
  });

  app.get("/api/guilds/:id", requireAuth, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: "guild not found" });
    return res.json(await guildPayload(client, guild));
  });

  app.post("/api/guilds/:id/temp/setup", requireAuth, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: "guild not found" });
    const { channelId } = req.body ?? {};
    const ch = guild.channels.cache.get(channelId);
    if (!ch || ch.type !== 2)
      return res.status(400).json({ error: "not a valid voice channel" });

    const data = getData();
    data.temp[guild.id] = data.temp[guild.id] ?? { trigger: null, channels: {} };
    data.temp[guild.id].trigger = channelId;
    save();
    return res.json({ ok: true, payload: await guildPayload(client, guild) });
  });

  app.post("/api/guilds/:id/temp/disable", requireAuth, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: "guild not found" });
    const data = getData();
    data.temp[guild.id] = { trigger: null, channels: {} };
    save();
    return res.json({ ok: true, payload: await guildPayload(client, guild) });
  });

  app.post("/api/guilds/:id/stats/setup", requireAuth, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: "guild not found" });
    try {
      await setupStats(guild);
      await refreshStats(guild);
      return res.json({ ok: true, payload: await guildPayload(client, guild) });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/guilds/:id/stats/refresh", requireAuth, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: "guild not found" });
    await refreshStats(guild);
    return res.json({ ok: true });
  });

  app.post("/api/guilds/:id/stats/disable", requireAuth, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: "guild not found" });
    await disableStats(guild);
    return res.json({ ok: true, payload: await guildPayload(client, guild) });
  });

  app.post("/api/commands/register", requireAuth, async (req, res) => {
    try {
      await registerCommands(client);
      return res.json({ ok: true });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.use(express.static(PUBLIC));

  const port = Number(process.env.PANEL_PORT || 3000);
  const host = process.env.PANEL_HOST || "127.0.0.1";
  const server = app.listen(port, host, () => {
    console.log(`[panel] dashboard running at http://${host}:${port}`);
  });
  return server;
}