const $ = (sel) => document.querySelector(sel);

let guilds = [];
let selectedGuildId = null;

async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  if (res.status === 401) {
    showLogin(true);
    throw new Error("unauthorized");
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "request failed");
  return data;
}

function toast(msg, isError = false) {
  const el = $("#toast");
  el.textContent = msg;
  el.classList.toggle("error", isError);
  el.classList.remove("hidden");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.add("hidden"), 3500);
}

function showLogin(show) {
  $("#login-screen").classList.toggle("hidden", !show);
  $("#app").classList.toggle("hidden", show);
}

function fmtUptime(sec) {
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return `${d}d ${h}h ${m}m`;
}

async function loadStatus() {
  try {
    const st = await api("/api/status");
    $("#status-dot").className = `dot ${st.online ? "online" : "offline"}`;
    $("#status-text").textContent = st.online ? st.tag : "offline";
    $("#status-meta").textContent = st.online
      ? `Ping ${st.ping}ms · up ${fmtUptime(st.uptime)} · ${st.guildCount} servers · ${st.totalMembers} members`
      : "";
  } catch {}
}

async function loadGuilds() {
  guilds = await api("/api/guilds");
  const list = $("#guild-list");
  list.innerHTML = "";
  for (const g of guilds) {
    const li = document.createElement("li");
    li.className = "guild-item";
    li.dataset.id = g.id;

    const avatar = document.createElement("div");
    avatar.className = "g-avatar";
    if (g.icon) {
      const img = document.createElement("img");
      img.src = g.icon;
      img.alt = "";
      avatar.appendChild(img);
    } else {
      avatar.textContent = g.name.charAt(0).toUpperCase();
    }

    const name = document.createElement("span");
    name.className = "g-name";
    name.textContent = g.name;

    li.append(avatar, name);
    li.addEventListener("click", () => selectGuild(g.id));
    list.appendChild(li);
  }
  if (selectedGuildId && guilds.some((g) => g.id === selectedGuildId)) {
    selectGuild(selectedGuildId);
  } else if (guilds.length) {
    selectGuild(guilds[0].id);
  }
}

function selectGuild(id) {
  selectedGuildId = id;
  document.querySelectorAll(".guild-item").forEach((it) => it.classList.toggle("selected", it.dataset.id === id));
  $("#empty-state").classList.add("hidden");
  $("#guild-view").classList.remove("hidden");
  renderGuild(guilds.find((g) => g.id === id));
}

function renderGuild(g) {
  if (!g) return;
  const icon = $("#guild-icon");
  if (g.icon) {
    icon.src = g.icon;
    icon.style.display = "";
  } else {
    icon.style.display = "none";
  }
  $("#guild-name").textContent = g.name;
  $("#guild-meta").textContent = `${g.memberCount} members · ${g.channels.length} text/voice channels`;

  const select = $("#temp-channel");
  select.innerHTML = "";
  const voice = g.channels.filter((c) => c.type === 2).sort((a, b) => a.name.localeCompare(b.name));
  if (!voice.length) {
    const opt = document.createElement("option");
    opt.textContent = "No voice channels in this server";
    opt.disabled = true;
    select.appendChild(opt);
    $("#btn-temp-setup").disabled = true;
  } else {
    $("#btn-temp-setup").disabled = false;
    for (const c of voice) {
      const opt = document.createElement("option");
      opt.value = c.id;
      opt.textContent = c.name;
      select.appendChild(opt);
    }
  }
  if (g.temp.triggerId) select.value = g.temp.triggerId;

  $("#temp-status").textContent = g.temp.enabled
    ? `Enabled — trigger: #${g.temp.triggerName ?? "(deleted)"}`
    : "Disabled — users won't get temporary channels.";
  $("#stats-status").textContent = g.stats.enabled
    ? "Enabled — live numbers are updated every 5 minutes."
    : "Disabled — create the stats channels to enable.";
}

/* --- actions --- */

async function withGuild(action, body = {}) {
  if (!selectedGuildId) return;
  const payload = await api(`/api/guilds/${selectedGuildId}/${action}`, {
    method: "POST",
    body
  });
  if (payload.payload) {
    const idx = guilds.findIndex((g) => g.id === selectedGuildId);
    guilds[idx] = payload.payload;
    renderGuild(payload.payload);
  }
  toast("Done");
  await loadStatus();
}

$("#login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const password = $("#password").value;
  try {
    await api("/api/login", { method: "POST", body: { password } });
    $("#login-error").classList.add("hidden");
    showLogin(false);
    $("#password").value = "";
    await refreshAll();
  } catch (err) {
    $("#login-error").textContent = "Wrong password";
    $("#login-error").classList.remove("hidden");
  }
});

$("#btn-logout").addEventListener("click", async () => {
  await api("/api/logout", { method: "POST", body: {} });
  showLogin(true);
});

$("#btn-temp-setup").addEventListener("click", () =>
  withGuild("temp/setup", { channelId: $("#temp-channel").value })
);

$("#btn-temp-disable").addEventListener("click", () => withGuild("temp/disable"));
$("#btn-stats-setup").addEventListener("click", () => withGuild("stats/setup"));
$("#btn-stats-refresh").addEventListener("click", () => withGuild("stats/refresh"));
$("#btn-stats-disable").addEventListener("click", () => withGuild("stats/disable"));

$("#btn-commands").addEventListener("click", async () => {
  try {
    await api("/api/commands/register", { method: "POST", body: {} });
    toast("Commands re-registered");
  } catch (err) {
    toast(err.message, true);
  }
});

async function refreshAll() {
  await Promise.all([loadStatus(), loadGuilds()]);
}

(async function init() {
  try {
    await api("/api/status");
    showLogin(false);
    await refreshAll();
  } catch {
    showLogin(true);
  }
  setInterval(loadStatus, 30_000);
})();